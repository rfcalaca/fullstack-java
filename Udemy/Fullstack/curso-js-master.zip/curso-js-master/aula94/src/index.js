import Pessoa, { nome, sobrenome } from './modulo1';

const p1 = new Pessoa(nome, sobrenome);
console.log(p1);
