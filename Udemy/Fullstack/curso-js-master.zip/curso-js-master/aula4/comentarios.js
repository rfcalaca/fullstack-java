/*
Comentário de block
Qualquer texto
*/

// Comentário de linha
